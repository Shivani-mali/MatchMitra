import { useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { db } from '../services/firebase';
import { useAuth } from '../context/AuthContext';
import Loader from '../components/Loader';
import LanguageSwitcher from '../components/LanguageSwitcher';

const Login = () => {
  const { t } = useTranslation();
  const { loginWithEmail, loginWithGoogle } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const nextPath = location.state?.from?.pathname || '/profile';

  const checkProfileAndNavigate = async (user) => {
    try {
      const docRef = doc(db, 'users', user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        navigate('/matches');
      } else {
        navigate('/profile');
      }
    } catch (error) {
      console.error('Error checking profile:', error);
      navigate('/profile');
    }
  };

  const submitLogin = async (event) => {
    event.preventDefault();
    setError('');
    setLoading(true);

    try {
      const userCredential = await loginWithEmail(email, password);
      await checkProfileAndNavigate(userCredential.user);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const loginGoogle = async () => {
    setError('');
    setLoading(true);

    try {
      const userCredential = await loginWithGoogle();
      await checkProfileAndNavigate(userCredential.user);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  if (loading) {
    return <Loader message={t('login.logging_in')} />;
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 p-4">
      <section className="w-full max-w-md rounded-2xl bg-white p-6 shadow-lg">
        <div className="mb-6 flex items-center justify-between">
          <div className="text-xl font-bold text-indigo-700">MatchMitra</div>
          <LanguageSwitcher />
        </div>
        <h1 className="text-2xl font-bold text-slate-800">{t('login.title')}</h1>
        <p className="mt-1 text-sm text-slate-500">{t('login.subtitle')}</p>

        <form onSubmit={submitLogin} className="mt-6 space-y-3">
          <input
            type="email"
            placeholder={t('login.email_placeholder')}
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="w-full rounded-lg border border-slate-200 px-3 py-2"
            required
          />
          <input
            type="password"
            placeholder={t('login.password_placeholder')}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="w-full rounded-lg border border-slate-200 px-3 py-2"
            required
          />
          {error && <p className="text-sm text-rose-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-indigo-600 px-3 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-70"
          >
            {t('common.login')}
          </button>
        </form>

        <button
          type="button"
          onClick={loginGoogle}
          disabled={loading}
          className="mt-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 font-medium text-slate-700 hover:bg-slate-50"
        >
          {t('login.google_button')}
        </button>

        <p className="mt-4 text-center text-sm text-slate-600">
          {t('common.no_account')}{' '}
          <Link to="/signup" className="font-medium text-indigo-600 hover:underline">
            {t('common.signup')}
          </Link>
        </p>
      </section>
    </main>
  );
};

export default Login;

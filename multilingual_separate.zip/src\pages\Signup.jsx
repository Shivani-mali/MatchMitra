import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Loader from '../components/Loader';
import { useAuth } from '../context/AuthContext';
import LanguageSwitcher from '../components/LanguageSwitcher';

const Signup = () => {
  const { t } = useTranslation();
  const { signupWithEmail } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submitSignup = async (event) => {
    event.preventDefault();
    setError('');
    setLoading(true);

    try {
      await signupWithEmail(email, password);
      navigate('/profile');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <Loader message={t('signup.creating_account')} />;
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-100 p-4">
      <section className="w-full max-w-md rounded-2xl bg-white p-6 shadow-lg">
        <div className="mb-6 flex items-center justify-between">
          <div className="text-xl font-bold text-indigo-700">MatchMitra</div>
          <LanguageSwitcher />
        </div>
        <h1 className="text-2xl font-bold text-slate-800">{t('signup.title')}</h1>
        <p className="mt-1 text-sm text-slate-500">{t('signup.subtitle')}</p>

        <form onSubmit={submitSignup} className="mt-6 space-y-3">
          <input
            type="email"
            placeholder={t('signup.email_placeholder')}
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="w-full rounded-lg border border-slate-200 px-3 py-2"
            required
          />
          <input
            type="password"
            placeholder={t('signup.password_placeholder')}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="w-full rounded-lg border border-slate-200 px-3 py-2"
            required
          />
          {error && <p className="text-sm text-rose-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-indigo-600 px-3 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-70"
          >
            {loading ? t('signup.creating_account') : t('signup.button')}
          </button>
        </form>

        <p className="mt-4 text-center text-sm text-slate-600">
          {t('common.have_account')}{' '}
          <Link to="/login" className="font-medium text-indigo-600 hover:underline">
            {t('common.login')}
          </Link>
        </p>
      </section>
    </main>
  );
};

export default Signup;

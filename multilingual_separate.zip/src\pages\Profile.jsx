import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Navbar from '../components/Navbar';
import { useAuth } from '../context/AuthContext';
import {
  calculateProfileCompletion,
  getProfileByUid,
  upsertProfile,
  uploadProfilePhoto,
  updateProfilePhotoURL,
} from '../services/firestoreService';

const initialProfile = {
  name: '',
  age: '',
  gender: '',
  location: '',
  religion: '',
  caste: '',
  profession: '',
  education: '',
  hobbies: '',
  bio: '',
  photoURL: '',
  height: '',
  maritalStatus: '',
  language: '',
  interests: '',
  willingToRelocate: false,
  partnerPreferences: {
    minAge: '',
    maxAge: '',
    location: '',
    religion: '',
    caste: '',
  },
};

const Profile = () => {
  const { t } = useTranslation();
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(initialProfile);
  const [photoPreview, setPhotoPreview] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const photoUploadRef = useRef(null);

  const localPhotoKey = user?.uid ? `profile-photo-${user.uid}` : null;

  useEffect(() => {
    return () => {
      if (photoPreview && photoPreview.startsWith('blob:')) {
        URL.revokeObjectURL(photoPreview);
      }
    };
  }, [photoPreview]);

  useEffect(() => {
    if (localPhotoKey) {
      const cachedPhoto = localStorage.getItem(localPhotoKey);
      if (cachedPhoto && !photoPreview) {
        setPhotoPreview(cachedPhoto);
        setProfile((prev) => ({ ...prev, photoURL: cachedPhoto }));
      }
    }
  }, [localPhotoKey]);

  useEffect(() => {
    if (!localPhotoKey) return;
    if (profile.photoURL && !profile.photoURL.startsWith('blob:')) {
      localStorage.setItem(localPhotoKey, profile.photoURL);
    }
  }, [localPhotoKey, profile.photoURL]);

  useEffect(() => {
    const loadProfile = async () => {
      if (!user?.uid) return;
      try {
        const data = await getProfileByUid(user.uid);
        if (data) {
          setIsEditing(true);
          const savedPhoto = data.photo || data.photoURL || '';
          setProfile({
            name: data.name || '',
            age: data.age || '',
            gender: data.gender || '',
            location: data.location || '',
            religion: data.religion || '',
            caste: data.caste || '',
            profession: data.profession || '',
            education: data.education || '',
            hobbies: data.hobbies ? data.hobbies.join(', ') : '',
            bio: data.bio || '',
            photoURL: savedPhoto,
            height: data.height || '',
            maritalStatus: data.maritalStatus || '',
            language: data.language || '',
            interests: data.interests ? data.interests.join(', ') : '',
            willingToRelocate: data.willingToRelocate || false,
            partnerPreferences: {
              minAge: data.partnerPreferences?.minAge || '',
              maxAge: data.partnerPreferences?.maxAge || '',
              location: data.partnerPreferences?.location || '',
              religion: data.partnerPreferences?.religion || '',
              caste: data.partnerPreferences?.caste || '',
            },
          });
          setPhotoPreview(savedPhoto);
        } else {
          setIsEditing(false);
        }
      } catch (error) {
        console.error('Failed to load profile:', error);
        setIsEditing(false);
      }
    };

    loadProfile();
  }, [user?.uid]);

  const completionPercent = useMemo(() => calculateProfileCompletion(profile), [profile]);

  const updateField = (field, value) => setProfile((prev) => ({ ...prev, [field]: value }));
  const updatePreference = (field, value) =>
    setProfile((prev) => ({
      ...prev,
      partnerPreferences: { ...prev.partnerPreferences, [field]: value },
    }));

  const handlePhotoSelected = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setMessage(t('profile.messages.invalid_image'));
      return;
    }

    const previewUrl = URL.createObjectURL(file);
    setPhotoPreview(previewUrl);
    setUploadingPhoto(true);
    setMessage(t('profile.messages.photo_selected'));

    const uploadPromise = uploadProfilePhoto(user.uid, file)
      .then(async (uploadedPhotoURL) => {
        setProfile((prev) => ({ ...prev, photoURL: uploadedPhotoURL }));
        setPhotoPreview(uploadedPhotoURL);
        if (localPhotoKey) {
          localStorage.setItem(localPhotoKey, uploadedPhotoURL);
        }
        if (user?.uid) {
          await updateProfilePhotoURL(user.uid, uploadedPhotoURL);
        }
        setMessage(t('profile.messages.photo_success'));
      })
      .catch((error) => {
        console.error('Photo upload failed:', error);
        setMessage(t('profile.messages.photo_error'));
      })
      .finally(() => {
        setUploadingPhoto(false);
      });

    photoUploadRef.current = uploadPromise;
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    if (!user?.uid) return;

    setSaving(true);
    setMessage('');

    try {
      const payload = {
        ...profile,
        uid: user.uid,
        email: user.email,
        age: Number(profile.age) || 0,
        photoURL: profile.photoURL,
        partnerPreferences: {
          ...profile.partnerPreferences,
          minAge: Number(profile.partnerPreferences.minAge) || null,
          maxAge: Number(profile.partnerPreferences.maxAge) || null,
        },
      };

      await upsertProfile(user.uid, payload);
      await refreshProfile();

      setProfile((prev) => ({ ...prev, photoURL: profile.photoURL }));
      setPhotoPreview(profile.photoURL);

      setMessage(t('profile.messages.save_success'));
      
      setTimeout(() => {
        navigate('/matches');
      }, 1500);
    } catch (error) {
      console.error('Profile save error:', error);
      setMessage(t('profile.messages.save_failed', { error: error.message }));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100">
      <Navbar />
      <div className="border-b-4 border-purple-600 bg-purple-50 px-4 py-3">
        <div className="mx-auto max-w-4xl">
          <h2 className="text-xl font-bold text-purple-900">👤 {t('common.profile').toUpperCase()}</h2>
        </div>
      </div>
      <main className="mx-auto max-w-4xl p-4 md:p-6">
        <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h1 className="text-2xl font-bold text-slate-800">
                {isEditing ? t('profile.title_edit') : t('profile.title_create')}
              </h1>
              <p className="text-sm text-slate-500">
                {isEditing ? t('profile.subtitle_edit') : t('profile.subtitle_create')}
              </p>
            </div>
             <div className="flex flex-col gap-2">
               {isEditing && profile.name && (
                 <>
                   <div className="text-right">
                     {profile?.isVerified && (
                       <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">
                         ✔️ {t('dashboard.verified')}
                       </span>
                     )}
                   </div>
                   <div className="flex items-center justify-end gap-2 rounded-lg bg-blue-50 px-3 py-2">
                     <span className="text-xs font-semibold text-blue-700">{t('profile.trust_score')}</span>
                     <span className="text-sm font-bold text-blue-900">{profile?.trustScore || 80}%</span>
                     <div className="h-2 w-24 overflow-hidden rounded-full bg-blue-200">
                       <div 
                         className="h-full bg-blue-600"
                         style={{ width: `${profile?.trustScore || 80}%` }}
                       />
                     </div>
                   </div>
                 </>
               )}
               <div className="rounded-full bg-indigo-50 px-3 py-1 text-sm font-medium text-indigo-700 text-center">
                 {t('profile.completion')}: {completionPercent}%
               </div>
            </div>
          </div>

          <form onSubmit={onSubmit} className="mt-6 grid gap-3 md:grid-cols-2">
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.name')} value={profile.name} onChange={(event) => updateField('name', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.age')} value={profile.age} onChange={(event) => updateField('age', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.gender')} value={profile.gender} onChange={(event) => updateField('gender', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.location')} value={profile.location} onChange={(event) => updateField('location', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.religion')} value={profile.religion} onChange={(event) => updateField('religion', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.caste')} value={profile.caste} onChange={(event) => updateField('caste', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.profession')} value={profile.profession} onChange={(event) => updateField('profession', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.education')} value={profile.education} onChange={(event) => updateField('education', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.height')} value={profile.height} onChange={(event) => updateField('height', event.target.value)} />
            <select className="rounded-lg border border-slate-200 px-3 py-2" value={profile.maritalStatus} onChange={(event) => updateField('maritalStatus', event.target.value)}>
              <option value="">{t('profile.labels.marital_status')}</option>
              <option value="single">Single</option>
              <option value="divorced">Divorced</option>
              <option value="widowed">Widowed</option>
            </select>
            <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.labels.language')} value={profile.language} onChange={(event) => updateField('language', event.target.value)} />
            <input className="rounded-lg border border-slate-200 px-3 py-2 md:col-span-2" placeholder={t('profile.labels.interests')} value={profile.interests} onChange={(event) => updateField('interests', event.target.value)} />
            <label className="flex items-center md:col-span-2">
              <input type="checkbox" checked={profile.willingToRelocate} onChange={(event) => updateField('willingToRelocate', event.target.checked)} className="mr-2" />
              {t('profile.labels.relocate')}
            </label>

            <div className="md:col-span-2 rounded-xl border border-slate-200 p-3">
              <h2 className="mb-2 text-sm font-semibold text-slate-700">{t('profile.partner_preferences.title')}</h2>
              <div className="grid gap-3 md:grid-cols-2">
                <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.partner_preferences.min_age')} value={profile.partnerPreferences.minAge} onChange={(event) => updatePreference('minAge', event.target.value)} />
                <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.partner_preferences.max_age')} value={profile.partnerPreferences.maxAge} onChange={(event) => updatePreference('maxAge', event.target.value)} />
                <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.partner_preferences.location')} value={profile.partnerPreferences.location} onChange={(event) => updatePreference('location', event.target.value)} />
                <input className="rounded-lg border border-slate-200 px-3 py-2" placeholder={t('profile.partner_preferences.religion')} value={profile.partnerPreferences.religion} onChange={(event) => updatePreference('religion', event.target.value)} />
                <input className="rounded-lg border border-slate-200 px-3 py-2 md:col-span-2" placeholder={t('profile.partner_preferences.caste')} value={profile.partnerPreferences.caste} onChange={(event) => updatePreference('caste', event.target.value)} />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="mb-1 block text-sm font-medium text-slate-700">{t('profile.labels.photo')}</label>
              <div className="flex flex-col gap-3 rounded-2xl border border-slate-200 p-3">
                <div className="flex items-center gap-4">
                  <img
                    src={photoPreview || profile.photoURL || 'https://placehold.co/120x120?text=Photo'}
                    alt="Profile preview"
                    className="h-24 w-24 rounded-2xl object-cover"
                  />
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoSelected}
                    className="text-sm text-slate-600"
                  />
                </div>
                <p className="text-sm text-slate-500">
                  {uploadingPhoto ? t('profile.messages.photo_uploading') : t('profile.labels.photo_upload_hint')}
                </p>
              </div>
            </div>

            {message && (
              <p className={`text-sm md:col-span-2 ${
                message.includes('failed') ? 'text-red-600' : 'text-emerald-600'
              }`}>
                {message}
              </p>
            )}

            <button
              type="submit"
              disabled={saving}
              className="md:col-span-2 rounded-lg bg-indigo-600 px-4 py-2 font-medium text-white hover:bg-indigo-700 disabled:opacity-70"
            >
              {saving
                ? t('profile.buttons.saving')
                : isEditing
                ? t('profile.buttons.update')
                : t('profile.buttons.save')}
            </button>
          </form>
        </section>
      </main>
    </div>
  );
};

export default Profile;

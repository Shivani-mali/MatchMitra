import { useState } from 'react';
import { useTranslation } from 'react-i18next';

const ProfileCard = ({
  profile,
  matchScore,
  onLike,
  onUnlike,
  onSkip,
  onViewDetails,
  onSendInterest,
  onReport,
  onBlock,
  onUnblock,
  isLiked,
  isBlocked,
  showUnlike,
}) => {
  const { t } = useTranslation();
  const [menuOpen, setMenuOpen] = useState(false);
  const actionLabel = showUnlike ? `💔 ${t('common.unlike')}` : `❤️ ${t('common.like')}`;

  return (
    <article className="relative overflow-hidden rounded-xl border border-slate-200 bg-white shadow-md transition hover:shadow-lg">
      <div className="flex gap-4 p-5">
        <img
          src={profile.photo || profile.photoURL || 'https://placehold.co/120x120?text=User'}
          alt={profile.name || t('common.unknown')}
          className="h-24 w-24 rounded-full object-cover"
        />

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h3 className="text-lg font-semibold text-slate-900 truncate">{profile.name || t('common.unknown')}</h3>
              <p className="mt-1 text-sm text-slate-500 truncate">
                {profile.age ? `${profile.age} ${t('common.years_short')}` : t('common.age_na')} · {profile.location || t('common.location_unknown')}
              </p>
               {/* Trust Score & Verified Badge */}
               <div className="mt-2 flex items-center gap-2">
                 {profile.isVerified && (
                   <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2 py-1 text-xs font-semibold text-green-700">
                     ✔️ {t('dashboard.verified')}
                   </span>
                 )}
                 <div className="flex items-center gap-1">
                   <span className="text-xs font-medium text-slate-600">{profile.trustScore || 80}%</span>
                   <div className="h-2 w-20 overflow-hidden rounded-full bg-slate-200">
                     <div 
                         className="h-full bg-emerald-600"
                       style={{ width: `${profile.trustScore || 80}%` }}
                     />
                   </div>
                 </div>
               </div>
              <p className="mt-3 text-sm font-medium text-slate-700 truncate">
                {profile.profession || t('common.no_profession')}
              </p>
              <p className="mt-2 max-w-full truncate text-sm text-slate-500">
                {profile.bio || t('common.no_bio')}
              </p>
            </div>
            <div className="shrink-0 text-right">
              <span className="inline-flex rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-700">
                {matchScore?.score ?? 0}% {t('common.match')}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="border-t border-slate-200 px-5 py-4">
        <div className="grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => (showUnlike ? onUnlike(profile) : onLike(profile))}
            className="inline-flex h-11 items-center justify-center rounded-xl bg-indigo-600 px-4 text-sm font-semibold text-white transition hover:bg-indigo-700"
          >
            {actionLabel}
          </button>
          <button
            type="button"
            onClick={() => onSendInterest(profile)}
            className="inline-flex h-11 items-center justify-center rounded-xl bg-slate-900 px-4 text-sm font-semibold text-white transition hover:bg-slate-800"
          >
            💌 {t('common.send_interest')}
          </button>
        </div>
      </div>

      <div className="absolute right-4 top-4">
        <button
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          className="inline-flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-white text-slate-500 transition hover:bg-slate-100"
          aria-label="More actions"
        >
          ⋮
        </button>

        {menuOpen && (
          <div className="absolute right-0 top-11 z-10 w-40 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-lg">
            <button
              type="button"
              onClick={() => {
                onViewDetails(profile);
                setMenuOpen(false);
              }}
              className="w-full px-4 py-3 text-left text-sm text-slate-700 transition hover:bg-slate-50"
            >
              {t('common.view_details')}
            </button>
            <button
              type="button"
              onClick={() => {
                onSkip(profile);
                setMenuOpen(false);
              }}
              className="w-full px-4 py-3 text-left text-sm text-slate-700 transition hover:bg-slate-50"
            >
              {t('common.skip')}
            </button>
            {showUnlike && isLiked && (
              <button
                type="button"
                onClick={() => {
                  onUnlike(profile);
                  setMenuOpen(false);
                }}
                className="w-full px-4 py-3 text-left text-sm text-slate-700 transition hover:bg-slate-50"
              >
                {t('common.unlike')}
              </button>
            )}
            {isBlocked ? (
              <button
                type="button"
                onClick={() => {
                  onUnblock(profile);
                  setMenuOpen(false);
                }}
                className="w-full px-4 py-3 text-left text-sm text-slate-700 transition hover:bg-slate-50"
              >
                {t('common.unblock')}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  onBlock(profile);
                  setMenuOpen(false);
                }}
                className="w-full px-4 py-3 text-left text-sm text-slate-700 transition hover:bg-slate-50"
              >
                {t('common.block')}
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                onReport(profile);
                setMenuOpen(false);
              }}
              className="w-full px-4 py-3 text-left text-sm text-red-600 transition hover:bg-slate-50"
            >
              {t('common.report')}
            </button>
          </div>
        )}
      </div>
    </article>
  );
};

export default ProfileCard;
